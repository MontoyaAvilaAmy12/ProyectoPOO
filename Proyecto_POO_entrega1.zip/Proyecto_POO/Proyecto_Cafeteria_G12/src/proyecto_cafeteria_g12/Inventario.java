/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_cafeteria_g12;

/**
 *
 * @author admin
 */
public class Inventario {
    private Producto[] productos;
    private int contador;
    
    public Inventario(int capacidad){
        this.productos = new Producto[capacidad];
        this.contador = 0;
    }
    
    public void registrarProducto(Producto nuevoProducto){
        if (contador < productos.length){
            productos[contador] = nuevoProducto;
            contador++;
        }
    }
    
    public void mostrarInventario(){
        
        for (int i=0; i < contador; i++){
            System.out.println("Producto: "+productos[i].getnombreProducto());
            System.out.println("Stock: "+productos[i].getstock());
            System.out.println("Precio: $"+productos[i].getprecio());
        }         
    }
}
