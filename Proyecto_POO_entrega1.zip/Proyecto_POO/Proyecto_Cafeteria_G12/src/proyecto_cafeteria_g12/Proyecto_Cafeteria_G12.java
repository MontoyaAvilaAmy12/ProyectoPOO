/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto_cafeteria_g12;

/**
 *
 * @author admin
 */
public class Proyecto_Cafeteria_G12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         System.out.println("\n=================================");
            System.out.println("          CAFFE & AROMA");
            System.out.println("=================================");
            System.out.println("               MENU");
            System.out.println("=================================");
            System.out.println("     PRODUCTO   |    PRECIO");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("=================================");
    }
    
}
