/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_cafeteria_g12;

/**
 *
 * @author admin
 */
public class Pedido{
    private int numeroPedido;
    private Producto producto;
    private int cantidad ;
    private double total; 

    public Pedido(int numeroPedido, Producto producto, int cantidad) {
        this.numeroPedido = numeroPedido;
        this.producto= producto;
        this.cantidad = cantidad;
        this.total = producto.getprecio() * cantidad;
    }

    public int getNumeroPedido() {
        return numeroPedido;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getTotal() {
        return total;
    }

    public void setNumeroPedido(int numeroPedido) {
        this.numeroPedido = numeroPedido;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public void mostrarPedido (){
        System.out.println("Numero de pedido: " + numeroPedido);
        System.out.println("Producto: " + producto.getnombreProducto());
        System.out.println("Cantidad: " + cantidad);
        System.out.println("Total a pagar: $" + total);
    }
    
}
