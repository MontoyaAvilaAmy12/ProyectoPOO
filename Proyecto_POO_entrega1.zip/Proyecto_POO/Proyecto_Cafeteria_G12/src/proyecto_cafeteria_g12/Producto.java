/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_cafeteria_g12;

/**
 *
 * @author admin
 */
public class Producto {
    private String nombreProducto;
    private String categoria;
    private double precio;
    private int stock;
    
    public Producto(String nombreProducto, String categoria, double precio, int stock){
        this.nombreProducto = nombreProducto;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
    }
    
    public String getnombreProducto(){
        return nombreProducto;
    }
    
    public String getcategoria(){
        return categoria;
    }
    
    public double getprecio(){
        return precio;
    }
    
    public int getstock(){
        return stock;
    }
    
    public void setnombreProducto(String nombreProducto){
        if (nombreProducto != null){
            this.nombreProducto = nombreProducto;
        }
    }
    
    public void setcategoria(String categoria){
        if (categoria != null){
            this.categoria = categoria;
        }
    }
    
    public void setprecio(double precio){
        if (precio > 0){
            this.precio = precio;
        }
    }
    
    public void setstock(int stock){
        if (stock >= 0){
            this.stock = stock;
        }
    }
    
    public void mostrarDatos(){
        System.out.println("Producto: "+this.nombreProducto+"   |   Categoria:"+this.categoria);
        System.out.println("Precio  : "+this.precio);
    }
}



